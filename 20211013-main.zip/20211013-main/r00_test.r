# File Encoding: UTF-8

# 第一行程式碼
print("Hello World!")

# 執行範例
x <- 1
y <- 2
z <- x + y
z

# 繪圖範例
plot(cars)